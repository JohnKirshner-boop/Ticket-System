USE ticket_system;

INSERT INTO agents (name, email, role, skill_level) VALUES
  ('L. Reyes', 'l.reyes@school.edu', 'Help Desk Manager', 3),
  ('R. Mendoza', 'r.mendoza@school.edu', 'Senior Systems Administrator', 3),
  ('P. Villanueva', 'p.villanueva@school.edu', 'Network Specialist', 2),
  ('K. Flores', 'k.flores@school.edu', 'Software Support Specialist', 2),
  ('J. Santos', 'j.santos@school.edu', 'Support Agent', 1),
  ('M. Garcia', 'm.garcia@school.edu', 'Field Technician', 1);

INSERT INTO escalation_rules (rule_name, condition_text, action_text, owner, target_minutes, sort_order) VALUES
  ('Urgent Priority SLA', 'Priority is Urgent', 'Escalate immediately, assign a senior agent, and target first response inside the urgent SLA.', 'Help Desk Manager', 60, 1),
  ('High Priority SLA', 'Priority is High', 'Prioritize in the High queue and assign a qualified agent before medium and low work.', 'Service Desk Lead', 240, 2),
  ('Medium Priority SLA', 'Priority is Medium', 'Route through standard support triage and keep the ticket within the normal response target.', 'Support Agent', 480, 3),
  ('Low Priority SLA', 'Priority is Low', 'Route after higher priorities while keeping the customer informed before the low-priority target.', 'Intake Coordinator', 1440, 4);

INSERT INTO tickets (
  ticket_no, requester_name, requester_email, title, description, category,
  priority, status, agent_id, escalation_level, sla_due_at, auto_escalated_at
) VALUES
  (
    'HD-1030',
    'Alyssa Reyes',
    'alyssa.reyes@school.edu',
    'Faculty portal login fails after password reset',
    'Requester completed password reset but still cannot log into the faculty portal.',
    'Account Access',
    'High',
    'Open',
    5,
    1,
    DATE_ADD(NOW(), INTERVAL 75 MINUTE),
    NULL
  ),
  (
    'HD-1031',
    'Mark Dela Cruz',
    'mark.delacruz@school.edu',
    'Computer laboratory Wi-Fi drops every 10 minutes',
    'Multiple lab computers disconnect from Wi-Fi during class sessions.',
    'Network',
    'Urgent',
    'Escalated',
    3,
    2,
    DATE_ADD(NOW(), INTERVAL 35 MINUTE),
    NULL
  ),
  (
    'HD-1032',
    'Nina Cortez',
    'nina.cortez@school.edu',
    'Suspicious email reported by admissions office',
    'Admissions staff received a suspicious email with a credential collection link.',
    'Security',
    'Urgent',
    'Escalated',
    2,
    3,
    DATE_SUB(NOW(), INTERVAL 25 MINUTE),
    NOW()
  ),
  (
    'HD-1033',
    'Prof. Lim',
    'prof.lim@school.edu',
    'Projector not detected in lecture room 204',
    'Lectern PC does not detect the room projector through HDMI.',
    'Hardware',
    'Medium',
    'In Progress',
    6,
    1,
    DATE_ADD(NOW(), INTERVAL 5 HOUR),
    NULL
  ),
  (
    'HD-1034',
    'Carlo Medina',
    'carlo.medina@school.edu',
    'Unable to install required design software',
    'Installer fails during license validation. User needs software before lab activity.',
    'Software',
    'High',
    'Pending User',
    4,
    1,
    DATE_ADD(NOW(), INTERVAL 3 HOUR),
    NULL
  ),
  (
    'HD-1035',
    'Registrar Desk',
    'registrar@school.edu',
    'Student ID scanner delayed during enrollment',
    'Front desk scanner responds slowly while processing enrollment forms.',
    'Hardware',
    'Low',
    'Open',
    6,
    1,
    DATE_ADD(NOW(), INTERVAL 18 HOUR),
    NULL
  );

INSERT INTO ticket_events (ticket_id, message) VALUES
  (1, 'Ticket created.'),
  (1, 'High priority rule applied: monitor for at-risk SLA.'),
  (2, 'Ticket created.'),
  (2, 'Urgent priority trigger applied: routed to senior response queue.'),
  (3, 'Ticket created.'),
  (3, 'Urgent priority trigger applied: routed to senior response queue.'),
  (3, 'Automatic escalation to level 3: SLA is overdue.'),
  (3, 'Over SLA: manager review required.'),
  (4, 'Ticket created.'),
  (4, 'Field technician assigned.'),
  (5, 'Ticket created.'),
  (5, 'Waiting for requester to provide installer log file.'),
  (6, 'Ticket created.'),
  (6, 'Added to Low priority queue.');

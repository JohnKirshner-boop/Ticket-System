function resolveApiBase() {
  if (window.location.protocol === "file:") {
    return "http://localhost/Ticket-System-main/api";
  }

  const path = window.location.pathname.endsWith("/")
    ? window.location.pathname
    : window.location.pathname.replace(/\/[^/]*$/, "/");

  return `${window.location.origin}${path}api`;
}

const API_BASE = resolveApiBase();
const AUTH_STORAGE_KEY = "helpDeskDemoUser";
const AGENT_ACCOUNTS_STORAGE_KEY = "helpDeskAgentAccounts";
const DEMO_USERS = {
  admin: {
    username: "admin",
    password: "admin123",
    role: "admin",
    roleLabel: "Administrator",
    name: "System Administrator",
    email: "admin@helpdesk.local",
    scopeLabel: "Full help desk access",
    allowedViews: ["dashboard", "tickets", "queues", "sla", "rules", "agents"],
    canCreateTicket: true
  },
  customer: {
    username: "customer",
    password: "customer123",
    role: "customer",
    roleLabel: "Customer",
    name: "Alyssa Reyes",
    email: "alyssa.reyes@school.edu",
    scopeLabel: "Personal ticket portal",
    allowedViews: ["customerPortal", "tickets"],
    canCreateTicket: true
  },
  agent: {
    username: "agent",
    password: "agent123",
    role: "agent",
    roleLabel: "Agent",
    name: "J. Santos",
    email: "j.santos@school.edu",
    scopeLabel: "Assigned queue coverage",
    allowedViews: ["agentWorkspace", "tickets", "sla"],
    canCreateTicket: false
  }
};

const pageCopy = {
  dashboard: {
    eyebrow: "Admin Portal",
    title: "Dashboard",
    subtitle: "Manage tickets, queues, SLA alerts, escalation rules, and support agents."
  },
  customerPortal: {
    eyebrow: "Customer Portal",
    title: "Customer Portal",
    subtitle: "Track your support requests and open a new ticket when you need help."
  },
  agentWorkspace: {
    eyebrow: "Agent Workspace",
    title: "Agent Workspace",
    subtitle: "Focus on tickets assigned to your agent account and respond to customer update requests."
  },
  tickets: {
    eyebrow: "Operations Console",
    title: "Tickets",
    subtitle: "View details, assign agents, escalate, reassign, and resolve tickets."
  },
  queues: {
    eyebrow: "Operations Console",
    title: "Queues",
    subtitle: "Queue numbers are grouped by priority and ordered by arrival time."
  },
  sla: {
    eyebrow: "Operations Console",
    title: "SLA Monitor",
    subtitle: "Track At Risk and Over SLA tickets."
  },
  rules: {
    eyebrow: "Admin Portal",
    title: "Escalation Rules",
    subtitle: "Priority-based backend triggers for routing and escalation."
  },
  agents: {
    eyebrow: "Admin Portal",
    title: "Agents",
    subtitle: "Create agent accounts and monitor current workload."
  }
};

let currentUser = null;
let tickets = [];
let agents = [];
let dashboard = null;
let queues = {};
let slaMonitor = { over_sla: [], at_risk: [] };
let rules = [];
let selectedTicketId = null;
let activePriorityFilter = "all";
let apiOnline = false;

const loginShell = document.querySelector("#loginShell");
const appShell = document.querySelector("#appShell");
const loginForm = document.querySelector("#loginForm");
const loginError = document.querySelector("#loginError");
const usernameInput = document.querySelector("#usernameInput");
const passwordInput = document.querySelector("#passwordInput");
const sessionName = document.querySelector("#sessionName");
const sessionRole = document.querySelector("#sessionRole");
const sessionEmail = document.querySelector("#sessionEmail");
const logoutButton = document.querySelector("#logoutButton");
const viewScope = document.querySelector("#viewScope");
const pageEyebrow = document.querySelector("#pageEyebrow");
const navItems = document.querySelectorAll("[data-view-target]");
const views = document.querySelectorAll(".view");
const filterChips = document.querySelectorAll("[data-priority-filter]");
const ticketTable = document.querySelector("#ticketTable");
const searchInput = document.querySelector("#ticketSearch");
const statusFilter = document.querySelector("#statusFilter");
const modal = document.querySelector("#ticketModal");
const form = document.querySelector("#ticketForm");
const requesterNameInput = form.querySelector('[name="requester_name"]');
const requesterEmailInput = form.querySelector('[name="requester_email"]');
const assignAgentSelect = document.querySelector("#assignAgentSelect");
const createAgentSelect = document.querySelector("#createAgentSelect");
const createAgentField = document.querySelector("#createAgentField");
const openTicketModalButton = document.querySelector("#openTicketModal");
const assignAgentBlock = document.querySelector("#assignAgentBlock");
const actionStack = document.querySelector(".action-stack");
const detailPermissionNote = document.querySelector("#detailPermissionNote");
const toast = document.querySelector("#toast");
const customerNewTicketButton = document.querySelector("#customerNewTicket");
const customerTicketActions = document.querySelector("#customerTicketActions");
const requestTicketUpdateButton = document.querySelector("#requestTicketUpdate");
const agentResponseForm = document.querySelector("#agentResponseForm");
const agentUpdateResponse = document.querySelector("#agentUpdateResponse");
const agentCreatePanel = document.querySelector("#agentCreatePanel");
const agentAccountForm = document.querySelector("#agentAccountForm");
const agentFormError = document.querySelector("#agentFormError");

function getStoredAgentAccounts() {
  try {
    const accounts = JSON.parse(window.localStorage.getItem(AGENT_ACCOUNTS_STORAGE_KEY) || "[]");
    return Array.isArray(accounts) ? accounts : [];
  } catch {
    return [];
  }
}

function saveStoredAgentAccounts(accounts) {
  window.localStorage.setItem(AGENT_ACCOUNTS_STORAGE_KEY, JSON.stringify(accounts));
}

function agentAccountKey(account) {
  return `agent:${account.agentId}`;
}

function agentAccountToUser(account) {
  return {
    username: account.username,
    password: account.password,
    role: "agent",
    roleLabel: "Agent",
    name: account.name,
    email: account.email,
    scopeLabel: "Assigned queue coverage",
    allowedViews: [...DEMO_USERS.agent.allowedViews],
    canCreateTicket: false,
    agentId: Number(account.agentId)
  };
}

function getKnownUsers() {
  const users = { ...DEMO_USERS };
  getStoredAgentAccounts().forEach((account) => {
    if (account.agentId && account.username && account.password) {
      users[agentAccountKey(account)] = agentAccountToUser(account);
    }
  });

  return users;
}

function buildUserSession(userKey) {
  const template = getKnownUsers()[userKey];
  return template
    ? {
        ...template,
        allowedViews: [...template.allowedViews],
        userKey,
        agentId: template.agentId ? Number(template.agentId) : null
      }
    : null;
}

function isAdmin() {
  return currentUser?.role === "admin";
}

function isAgent() {
  return currentUser?.role === "agent";
}

function isCustomer() {
  return currentUser?.role === "customer";
}

function canCreateTicket() {
  return Boolean(currentUser?.canCreateTicket);
}

function getAllowedViews() {
  return currentUser?.allowedViews || [];
}

function firstAllowedView() {
  return getAllowedViews()[0] || "dashboard";
}

function canView(viewName) {
  return getAllowedViews().includes(viewName);
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, (character) => {
    const entities = {
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#039;"
    };
    return entities[character];
  });
}

async function api(path, options = {}) {
  const response = await fetch(`${API_BASE}/${path.replace(/^\//, "")}`, {
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      ...(options.headers || {})
    },
    ...options
  });

  const text = await response.text();
  let payload = {};
  try {
    payload = text ? JSON.parse(text) : {};
  } catch {
    throw new Error("The backend returned invalid JSON. Check Apache and PHP in XAMPP.");
  }

  if (!response.ok) {
    throw new Error(payload.message || payload.error || `Request failed (${response.status})`);
  }

  return payload;
}

function showToast(message) {
  toast.textContent = message;
  toast.classList.remove("hidden");
  window.clearTimeout(showToast.timer);
  showToast.timer = window.setTimeout(() => toast.classList.add("hidden"), 2600);
}

function setConnection(online, message = "") {
  apiOnline = online;
  const status = document.querySelector("#connectionStatus");
  status.classList.toggle("offline", !online);
  document.querySelector("#connectionText").textContent = online ? "Backend connected" : "Backend offline";

  const banner = document.querySelector("#apiBanner");
  if (online) {
    banner.classList.add("hidden");
    banner.textContent = "";
  } else {
    banner.textContent =
      message ||
      "Backend is not reachable. Start Apache and MySQL in XAMPP, then import backend/database/schema.sql and seed.sql.";
    banner.classList.remove("hidden");
  }
}

function priorityClass(priority) {
  return String(priority || "").toLowerCase();
}

function slaClass(sla) {
  return String(sla?.status || "")
    .toLowerCase()
    .replace(/[\s-]+/g, "_");
}

function slaBadge(sla) {
  return `<span class="sla-label ${slaClass(sla)}">${escapeHtml(sla?.label || "-")}</span>`;
}

function formatMinutes(minutes) {
  const total = Number(minutes || 0);
  if (total <= 0) {
    return "Immediate";
  }

  if (total < 60) {
    return `${total} min`;
  }

  const hours = total / 60;
  if (hours < 24) {
    return Number.isInteger(hours) ? `${hours} hr` : `${hours.toFixed(1)} hr`;
  }

  const days = hours / 24;
  return Number.isInteger(days) ? `${days} day` : `${days.toFixed(1)} days`;
}

function hasOpenUpdateRequest(ticket) {
  const latestUpdateEvent = (ticket?.events || []).find((event) =>
    /Customer requested an update|Agent response to update request/.test(event.message || "")
  );

  return Boolean(latestUpdateEvent?.message?.includes("Customer requested an update"));
}

function toggleElement(element, visible) {
  if (!element) {
    return;
  }

  element.classList.toggle("hidden", !visible);
}

function setLoginError(message = "") {
  loginError.textContent = message;
  loginError.classList.toggle("hidden", !message);
}

function setAgentFormError(message = "") {
  if (!agentFormError) {
    return;
  }

  agentFormError.textContent = message;
  agentFormError.classList.toggle("hidden", !message);
}

function applyAuthState() {
  const signedIn = Boolean(currentUser);
  loginShell.classList.toggle("hidden", signedIn);
  appShell.classList.toggle("hidden", !signedIn);
}

function updateSessionPanel() {
  if (!currentUser) {
    return;
  }

  sessionName.textContent = currentUser.name;
  sessionRole.textContent = currentUser.roleLabel;
  sessionEmail.textContent = currentUser.email;
  viewScope.textContent = currentUser.scopeLabel;
}

function persistSession() {
  if (currentUser?.userKey) {
    window.localStorage.setItem(AUTH_STORAGE_KEY, currentUser.userKey);
  }
}

function restoreSession() {
  const userKey = window.localStorage.getItem(AUTH_STORAGE_KEY);
  currentUser = buildUserSession(userKey);
  return Boolean(currentUser);
}

function clearSession() {
  window.localStorage.removeItem(AUTH_STORAGE_KEY);
}

function getPageCopy(viewName) {
  if (isCustomer() && viewName === "tickets") {
    return {
      eyebrow: "Customer Portal",
      title: "My Tickets",
      subtitle: "Review your requests and create a new help desk ticket when you need support."
    };
  }

  if (isAgent() && viewName === "tickets") {
    return {
      eyebrow: "Agent Workspace",
      title: "Assigned Tickets",
      subtitle: "Work tickets matched to the signed-in agent account."
    };
  }

  if (isAgent() && ["queues", "sla"].includes(viewName)) {
    return {
      ...(pageCopy[viewName] || pageCopy.agentWorkspace),
      eyebrow: "Agent Workspace"
    };
  }

  return pageCopy[viewName] || pageCopy.dashboard;
}

function canShowNewTicketButton(viewName) {
  if (!canCreateTicket()) {
    return false;
  }

  if (isAdmin()) {
    return viewName === "tickets";
  }

  return isCustomer() && viewName === "tickets";
}

function showView(viewName) {
  if (!currentUser) {
    return;
  }

  const safeView = canView(viewName) ? viewName : firstAllowedView();
  const copy = getPageCopy(safeView);

  views.forEach((view) => view.classList.toggle("active", view.dataset.view === safeView));
  navItems.forEach((item) => item.classList.toggle("active", item.dataset.viewTarget === safeView));

  pageEyebrow.textContent = copy.eyebrow || "Operations Console";
  document.querySelector("#pageTitle").textContent = copy.title;
  document.querySelector("#pageSubtitle").textContent = copy.subtitle;
  toggleElement(openTicketModalButton, canShowNewTicketButton(safeView));
  window.location.hash = safeView;
}

function getVisibleTickets() {
  if (!currentUser) {
    return [];
  }

  if (isCustomer()) {
    const customerEmail = currentUser.email.toLowerCase();
    return tickets.filter((ticket) => String(ticket.requester_email || "").toLowerCase() === customerEmail);
  }

  if (isAgent()) {
    return getAgentTickets();
  }

  return tickets;
}

function getAgentTickets() {
  if (!currentUser?.agentId) {
    return [];
  }

  return tickets.filter((ticket) => Number(ticket.agent_id) === Number(currentUser.agentId));
}

function selectedTicket() {
  const visibleTickets = getVisibleTickets();
  return visibleTickets.find((ticket) => ticket.id === selectedTicketId) || visibleTickets[0] || null;
}

function getFilteredTickets() {
  const query = searchInput.value.trim().toLowerCase();
  const status = statusFilter.value;

  return getVisibleTickets().filter((ticket) => {
    const matchesText = [
      ticket.id,
      ticket.title,
      ticket.requester_name,
      ticket.requester_email,
      ticket.category,
      ticket.priority,
      ticket.agent_name
    ]
      .join(" ")
      .toLowerCase()
      .includes(query);

    const matchesPriority = activePriorityFilter === "all" || ticket.priority === activePriorityFilter;
    const matchesStatus = status === "all" || ticket.status === status;

    return matchesText && matchesPriority && matchesStatus;
  });
}

function deriveDashboardFromTickets(sourceTickets) {
  const visibleTickets = sourceTickets || [];
  const activeTickets = visibleTickets.filter((ticket) => ticket.status !== "Resolved");
  const recentActivity = visibleTickets
    .flatMap((ticket) =>
      (ticket.events || []).slice(-2).map((event) => `${ticket.id}: ${event.message}`)
    )
    .slice(-6)
    .reverse();

  return {
    open_tickets: activeTickets.length,
    at_risk_sla: visibleTickets.filter((ticket) => slaClass(ticket.sla) === "at_risk").length,
    over_sla: visibleTickets.filter((ticket) => slaClass(ticket.sla) === "over_sla").length,
    resolved_today: visibleTickets.filter((ticket) => ticket.status === "Resolved").length,
    watchlist: visibleTickets
      .filter((ticket) => ["Urgent", "High"].includes(ticket.priority) || ["at_risk", "over_sla"].includes(slaClass(ticket.sla)))
      .slice(0, 4),
    priority_snapshot: ["Urgent", "High", "Medium", "Low"].map((priority) => ({
      priority,
      count: activeTickets.filter((ticket) => ticket.priority === priority).length
    })),
    recent_activity: recentActivity
  };
}

function getScopedDashboardPayload() {
  if (!currentUser) {
    return null;
  }

  if (isCustomer() || isAgent()) {
    return deriveDashboardFromTickets(getVisibleTickets());
  }

  return dashboard || deriveDashboardFromTickets(getVisibleTickets());
}

function getScopedQueues() {
  return isCustomer() || isAgent() ? {} : queues;
}

function getScopedSlaMonitor() {
  if (isCustomer()) {
    return { over_sla: [], at_risk: [] };
  }

  if (isAgent()) {
    const assigned = getAgentTickets().filter((ticket) => ticket.status !== "Resolved");
    return {
      over_sla: assigned.filter((ticket) => slaClass(ticket.sla) === "over_sla"),
      at_risk: assigned.filter((ticket) => slaClass(ticket.sla) === "at_risk")
    };
  }

  return slaMonitor;
}

function canManageTicket(ticket) {
  if (!ticket || !currentUser) {
    return false;
  }

  if (isAdmin()) {
    return true;
  }

  if (isAgent()) {
    return Boolean(currentUser.agentId) && Number(ticket.agent_id) === Number(currentUser.agentId);
  }

  return false;
}

function syncAgentIdentity() {
  if (!isAgent()) {
    return;
  }

  const agentMatch = agents.find(
    (agent) => String(agent.email || "").toLowerCase() === currentUser.email.toLowerCase()
  );

  currentUser.agentId = agentMatch ? Number(agentMatch.id) : null;
}

function clearTicketDetails() {
  document.querySelector("#detailTitle").textContent = "No ticket selected";
  document.querySelector("#detailId").textContent = "-";
  document.querySelector("#detailRequester").textContent = "-";
  document.querySelector("#detailEmail").textContent = "-";
  document.querySelector("#detailAgent").textContent = "-";
  document.querySelector("#detailPriority").textContent = "-";
  document.querySelector("#detailQueue").textContent = "-";
  document.querySelector("#detailSla").textContent = "-";
  document.querySelector("#detailEscalation").textContent = "-";
  document.querySelector("#detailDescription").textContent = "-";
  document.querySelector("#matchingRules").innerHTML = "<li>No trigger currently applies.</li>";
  document.querySelector("#activityLog").innerHTML = "<li>No activity recorded.</li>";
}

function updateDetailAccess() {
  const ticket = selectedTicket();
  const canAct = canManageTicket(ticket);
  const showAssignment = isAdmin() && Boolean(ticket);
  const showActions = Boolean(ticket) && (isAdmin() || isAgent());
  const canRequestUpdate = Boolean(ticket) && isCustomer() && ticket.status !== "Resolved";
  const canRespondToUpdate = Boolean(ticket) && isAgent() && canAct && hasOpenUpdateRequest(ticket);
  let message = "";

  toggleElement(assignAgentBlock, showAssignment);
  toggleElement(actionStack, showActions);
  toggleElement(customerTicketActions, canRequestUpdate);
  toggleElement(agentResponseForm, canRespondToUpdate);

  document.querySelector("#escalateTicket").disabled = !canAct;
  document.querySelector("#reassignTicket").disabled = !canAct;
  document.querySelector("#resolveTicket").disabled = !canAct;
  requestTicketUpdateButton.disabled = !canRequestUpdate || hasOpenUpdateRequest(ticket);

  if (!ticket) {
    message = isCustomer()
      ? "Create a ticket to start your request history."
      : "Select a ticket to view its details and available actions.";
  } else if (isCustomer()) {
    message = hasOpenUpdateRequest(ticket)
      ? "An update has already been requested. The assigned agent can respond from their workspace."
      : "You can request a status update when you need more information about this ticket.";
  } else if (isAgent() && !canAct) {
    message = currentUser.agentId
      ? "This ticket is not assigned to the signed-in agent account, so ticket actions are disabled."
      : "The hard-coded agent account could not be matched to the backend roster, so ticket actions are disabled.";
  } else if (isAgent() && ticket && !hasOpenUpdateRequest(ticket)) {
    message = "No customer update request is open for this ticket.";
  }

  detailPermissionNote.textContent = message;
  toggleElement(detailPermissionNote, Boolean(message));
}

function renderTable() {
  const rows = getFilteredTickets();
  if (!rows.length) {
    ticketTable.innerHTML = `<tr><td class="empty-state" colspan="7">No tickets match the current filters.</td></tr>`;
    return;
  }

  ticketTable.innerHTML = rows
    .map((ticket) => {
      const queue = ticket.queue_position ? `#${ticket.queue_position}` : "-";
      return `
        <tr data-ticket-id="${escapeHtml(ticket.id)}" class="${ticket.id === selectedTicketId ? "selected" : ""}">
          <td>
            <div class="ticket-title">
              <strong>${escapeHtml(ticket.title)}</strong>
              <span>${escapeHtml(ticket.id)} / ${escapeHtml(ticket.category)}</span>
            </div>
          </td>
          <td>${escapeHtml(ticket.requester_name)}</td>
          <td>${escapeHtml(ticket.agent_name || "Unassigned")}</td>
          <td><span class="pill queue">${escapeHtml(queue)}</span></td>
          <td><span class="pill ${priorityClass(ticket.priority)}">${escapeHtml(ticket.priority)}</span></td>
          <td><span class="pill status">${escapeHtml(ticket.status)}</span></td>
          <td>${slaBadge(ticket.sla)}<br><small>${escapeHtml(ticket.sla?.display || "")}</small></td>
        </tr>
      `;
    })
    .join("");

  ticketTable.querySelectorAll("tr[data-ticket-id]").forEach((row) => {
    row.addEventListener("click", () => {
      selectedTicketId = row.dataset.ticketId;
      renderAll();
    });
  });
}

function renderDetails() {
  const ticket = selectedTicket();
  if (!ticket) {
    clearTicketDetails();
    updateDetailAccess();
    return;
  }

  selectedTicketId = ticket.id;
  document.querySelector("#detailTitle").textContent = ticket.title;
  document.querySelector("#detailId").textContent = ticket.id;
  document.querySelector("#detailRequester").textContent = ticket.requester_name;
  document.querySelector("#detailEmail").textContent = ticket.requester_email || "-";
  document.querySelector("#detailAgent").textContent = ticket.agent_name
    ? `${ticket.agent_name}${ticket.agent_role ? ` (${ticket.agent_role})` : ""}`
    : "Unassigned";
  document.querySelector("#detailPriority").innerHTML =
    `<span class="pill ${priorityClass(ticket.priority)}">${escapeHtml(ticket.priority)}</span>`;
  document.querySelector("#detailQueue").textContent = ticket.queue_position
    ? `#${ticket.queue_position} in ${ticket.priority} queue`
    : "Not in active queue";
  document.querySelector("#detailSla").innerHTML = `${slaBadge(ticket.sla)} ${escapeHtml(ticket.sla?.display || "")}`;
  document.querySelector("#detailEscalation").textContent = `Level ${ticket.escalation_level}`;
  document.querySelector("#detailDescription").textContent = ticket.description || "No description provided.";

  if (assignAgentSelect.options.length) {
    assignAgentSelect.value = ticket.agent_id ? String(ticket.agent_id) : "";
  }

  const matching = ticket.matching_rules || [];
  document.querySelector("#matchingRules").innerHTML = matching.length
    ? matching.map((rule) => `<li>${escapeHtml(rule.rule_name)}</li>`).join("")
    : "<li>No trigger currently applies.</li>";

  const events = ticket.events || [];
  document.querySelector("#activityLog").innerHTML = events.length
    ? events.map((event) => `<li>${escapeHtml(event.message)}</li>`).join("")
    : "<li>No activity recorded.</li>";

  updateDetailAccess();
}

function renderMetrics() {
  const metrics = getScopedDashboardPayload();
  if (!metrics) {
    return;
  }

  document.querySelector("#openTickets").textContent = metrics.open_tickets ?? 0;
  document.querySelector("#slaRisk").textContent = metrics.at_risk_sla ?? 0;
  document.querySelector("#overSla").textContent = metrics.over_sla ?? 0;
  document.querySelector("#resolvedToday").textContent = metrics.resolved_today ?? 0;
}

function ticketCard(ticket) {
  return `
    <article class="watch-card">
      <header>
        <h4>${escapeHtml(ticket.id)}</h4>
        <span class="pill ${priorityClass(ticket.priority)}">${escapeHtml(ticket.priority)}</span>
      </header>
      <p>${escapeHtml(ticket.title)}</p>
      <p>${escapeHtml(ticket.agent_name || "Unassigned")} &middot; ${escapeHtml(ticket.sla?.label)} &middot; ${escapeHtml(ticket.sla?.display)}</p>
    </article>
  `;
}

function customerTicketCard(ticket) {
  const updateOpen = hasOpenUpdateRequest(ticket);
  const canAsk = ticket.status !== "Resolved" && !updateOpen;
  return `
    <article class="watch-card">
      <header>
        <h4>${escapeHtml(ticket.id)}</h4>
        <span class="pill ${priorityClass(ticket.priority)}">${escapeHtml(ticket.priority)}</span>
      </header>
      <p>${escapeHtml(ticket.title)}</p>
      <p>${slaBadge(ticket.sla)} ${escapeHtml(ticket.sla?.display || "")} &middot; ${escapeHtml(ticket.status)}</p>
      <button
        class="secondary-button request-update-card"
        data-request-update-ticket="${escapeHtml(ticket.id)}"
        type="button"
        ${canAsk ? "" : "disabled"}
      >${updateOpen ? "Update Requested" : "Request Update"}</button>
    </article>
  `;
}

function agentUpdateCard(ticket) {
  return `
    <article class="watch-card">
      <header>
        <h4>${escapeHtml(ticket.id)}</h4>
        <span class="pill ${priorityClass(ticket.priority)}">${escapeHtml(ticket.priority)}</span>
      </header>
      <p>${escapeHtml(ticket.title)}</p>
      <p>${escapeHtml(ticket.requester_name)} is waiting for a response.</p>
      <button class="secondary-button open-ticket-card" data-open-ticket="${escapeHtml(ticket.id)}" type="button">
        Open Ticket
      </button>
    </article>
  `;
}

function renderDashboard() {
  const model = getScopedDashboardPayload();
  if (!model) {
    return;
  }

  document.querySelector("#watchlist").innerHTML = (model.watchlist || []).length
    ? model.watchlist.map(ticketCard).join("")
    : '<p class="empty-state">No priority alerts right now.</p>';

  document.querySelector("#prioritySnapshot").innerHTML = (model.priority_snapshot || [])
    .map(
      (item) => `
        <article class="priority-card ${priorityClass(item.priority)}">
          <header>
            <h4>${escapeHtml(item.priority)}</h4>
            <strong>${item.count}</strong>
          </header>
          <p>${item.count === 1 ? "1 active ticket" : `${item.count} active tickets`}</p>
        </article>
      `
    )
    .join("");

  document.querySelector("#dashboardTimeline").innerHTML = (model.recent_activity || []).length
    ? model.recent_activity.map((activity) => `<li>${escapeHtml(activity)}</li>`).join("")
    : "<li>No recent activity.</li>";
}

function renderCustomerPortal() {
  const customerTickets = isCustomer() ? getVisibleTickets() : [];
  const active = customerTickets.filter((ticket) => ticket.status !== "Resolved");
  const closeDeadlines = active.filter((ticket) => slaClass(ticket.sla) === "at_risk");
  const overSla = active.filter((ticket) => slaClass(ticket.sla) === "over_sla");
  const updateRequests = active.filter(hasOpenUpdateRequest);
  const deadlineTickets = [...overSla, ...closeDeadlines].slice(0, 5);

  document.querySelector("#customerActiveTickets").textContent = active.length;
  document.querySelector("#customerCloseDeadlines").textContent = closeDeadlines.length;
  document.querySelector("#customerOverSlaTickets").textContent = overSla.length;
  document.querySelector("#customerUpdateRequests").textContent = updateRequests.length;

  document.querySelector("#customerDeadlineCards").innerHTML = deadlineTickets.length
    ? deadlineTickets.map(customerTicketCard).join("")
    : '<p class="empty-state">No close deadlines or Over SLA tickets right now.</p>';

  document.querySelector("#customerTicketCards").innerHTML = customerTickets.length
    ? customerTickets.slice(0, 5).map(customerTicketCard).join("")
    : '<p class="empty-state">No tickets yet. Create one when you need help.</p>';
}

function renderAgentWorkspace() {
  const assigned = isAgent() ? getAgentTickets() : [];
  const active = assigned.filter((ticket) => ticket.status !== "Resolved");
  const priorityTickets = active.filter((ticket) => ["Urgent", "High"].includes(ticket.priority));
  const slaAlerts = active.filter((ticket) => ["at_risk", "over_sla"].includes(slaClass(ticket.sla)));
  const updateRequests = active.filter(hasOpenUpdateRequest);

  document.querySelector("#agentAssignedTickets").textContent = active.length;
  document.querySelector("#agentPriorityTickets").textContent = priorityTickets.length;
  document.querySelector("#agentSlaAlerts").textContent = slaAlerts.length;
  document.querySelector("#agentResolvedTickets").textContent = assigned.filter(
    (ticket) => ticket.status === "Resolved"
  ).length;

  document.querySelector("#agentAssignedCards").innerHTML = assigned.length
    ? assigned.slice(0, 5).map(ticketCard).join("")
    : '<p class="empty-state">No tickets are assigned to this agent account.</p>';

  document.querySelector("#agentUpdateCards").innerHTML = updateRequests.length
    ? updateRequests.map(agentUpdateCard).join("")
    : '<p class="empty-state">No customer update requests are waiting.</p>';

  const notice = document.querySelector("#agentIdentityNotice");
  const message = currentUser?.agentId
    ? `Matched to agent record #${currentUser.agentId}.`
    : "This agent login is not matched to a roster record yet, so assigned-ticket actions are disabled.";
  notice.textContent = message;
  toggleElement(notice, isAgent());
}

function renderQueues() {
  const scopedQueues = getScopedQueues();
  const priorities = ["Urgent", "High", "Medium", "Low"];
  document.querySelector("#priorityQueueCards").innerHTML = priorities
    .map((priority) => {
      const queue = scopedQueues[priority] || { count: 0, tickets: [] };
      const next = queue.tickets?.[0];
      return `
        <article class="priority-card ${priorityClass(priority)}">
          <header>
            <h4>${priority} Queue</h4>
            <strong>${queue.count || 0}</strong>
          </header>
          <p>${next ? `Next: ${escapeHtml(next.id)} (#${next.queue_position})` : "Queue is clear"}</p>
        </article>
      `;
    })
    .join("");

  const rows = priorities.flatMap((priority) => scopedQueues[priority]?.tickets || []);
  document.querySelector("#queueTableBody").innerHTML = rows.length
    ? rows
        .map(
          (ticket) => `
        <tr>
          <td><span class="pill ${priorityClass(ticket.priority)}">${escapeHtml(ticket.priority)}</span></td>
          <td><span class="pill queue">#${escapeHtml(ticket.queue_position)}</span></td>
          <td>${escapeHtml(ticket.id)}</td>
          <td>${escapeHtml(ticket.title)}</td>
          <td>${escapeHtml(ticket.agent_name || "Unassigned")}</td>
          <td>${slaBadge(ticket.sla)} ${escapeHtml(ticket.sla?.display || "")}</td>
        </tr>
      `
        )
        .join("")
    : '<tr><td class="empty-state" colspan="6">All queues are clear.</td></tr>';
}

function renderSlaMonitor() {
  const scopedSla = getScopedSlaMonitor();
  document.querySelector("#overSlaList").innerHTML = (scopedSla.over_sla || []).length
    ? scopedSla.over_sla.map(ticketCard).join("")
    : '<p class="empty-state">No Over SLA tickets.</p>';

  document.querySelector("#atRiskList").innerHTML = (scopedSla.at_risk || []).length
    ? scopedSla.at_risk.map(ticketCard).join("")
    : '<p class="empty-state">No At Risk tickets.</p>';
}

function renderAgents() {
  const options = agents
    .map((agent) => `<option value="${agent.id}">${escapeHtml(agent.name)} - ${escapeHtml(agent.role)}</option>`)
    .join("");

  assignAgentSelect.innerHTML = `<option value="">Select agent</option>${options}`;
  createAgentSelect.innerHTML = `<option value="">Auto assign</option>${options}`;

  const max = Math.max(...agents.map((agent) => Number(agent.active_tickets || 0)), 1);
  document.querySelector("#workloadBars").innerHTML = agents.length
    ? agents
        .map(
          (agent) => `
        <div class="bar-row">
          <div class="bar-meta">
            <span>${escapeHtml(agent.name)}</span>
            <span>${agent.active_tickets} active</span>
          </div>
          <div class="bar-track" aria-hidden="true">
            <div class="bar-fill" style="width: ${(Number(agent.active_tickets || 0) / max) * 100}%"></div>
          </div>
        </div>
      `
        )
        .join("")
    : '<p class="empty-state">No agents found.</p>';

  document.querySelector("#agentGrid").innerHTML = agents.length
    ? agents
        .map(
          (agent) => `
        <article class="roster-card">
          <header>
            <h4>${escapeHtml(agent.name)}</h4>
            <span class="pill status">${agent.active_tickets} active</span>
          </header>
          <p>${escapeHtml(agent.role)}</p>
          <p>${escapeHtml(agent.email)}</p>
        </article>
      `
        )
        .join("")
    : '<p class="empty-state">No agents found.</p>';
}

function renderRules() {
  document.querySelector("#rulesTableBody").innerHTML = rules.length
    ? rules
        .map(
          (rule) => `
        <tr>
          <td>${escapeHtml(rule.rule_name)}</td>
          <td>${escapeHtml(rule.condition_text)}</td>
          <td>${escapeHtml(rule.action_text)}</td>
          <td>${escapeHtml(rule.owner)}</td>
          <td>${formatMinutes(rule.target_minutes)}</td>
        </tr>
      `
        )
        .join("")
    : '<tr><td class="empty-state" colspan="5">No escalation rules found.</td></tr>';
}

function renderAll() {
  renderAgents();
  renderTable();
  renderDetails();
  renderMetrics();
  renderDashboard();
  renderCustomerPortal();
  renderAgentWorkspace();
  renderQueues();
  renderSlaMonitor();
  renderRules();
}

function applyTicketFormDefaults() {
  requesterNameInput.readOnly = isCustomer();
  requesterEmailInput.readOnly = isCustomer();

  if (isCustomer()) {
    requesterNameInput.value = currentUser.name;
    requesterEmailInput.value = currentUser.email;
    createAgentSelect.value = "";
  }
}

function syncRoleUi(preferredView = "") {
  if (!currentUser) {
    return;
  }

  const allowedViews = new Set(getAllowedViews());
  navItems.forEach((item) => {
    item.classList.toggle("hidden", !allowedViews.has(item.dataset.viewTarget));
  });

  toggleElement(openTicketModalButton, canCreateTicket());
  toggleElement(createAgentField, isAdmin());
  toggleElement(agentCreatePanel, isAdmin());
  updateSessionPanel();
  updateDetailAccess();
  showView(preferredView || window.location.hash.replace("#", "") || firstAllowedView());
}

function isUsernameTaken(username) {
  const normalized = username.trim().toLowerCase();
  return Object.values(getKnownUsers()).some((user) => user.username.toLowerCase() === normalized);
}

function storeAgentAccount(agent, username, password) {
  const accounts = getStoredAgentAccounts().filter((account) => Number(account.agentId) !== Number(agent.id));
  accounts.push({
    agentId: Number(agent.id),
    name: agent.name,
    email: agent.email,
    role: agent.role,
    username,
    password
  });
  saveStoredAgentAccounts(accounts);
}

async function loadData() {
  const [ticketPayload, dashboardPayload, queuePayload, slaPayload, agentPayload, rulesPayload] = await Promise.all([
    api("tickets"),
    api("dashboard"),
    api("queues"),
    api("sla"),
    api("agents"),
    api("rules")
  ]);

  tickets = ticketPayload.tickets || [];
  dashboard = dashboardPayload;
  queues = queuePayload.queues || {};
  slaMonitor = slaPayload || { over_sla: [], at_risk: [] };
  agents = agentPayload.agents || [];
  rules = rulesPayload.rules || [];

  syncAgentIdentity();

  const visibleTickets = getVisibleTickets();
  if (!selectedTicketId && visibleTickets.length) {
    selectedTicketId = visibleTickets[0].id;
  } else if (selectedTicketId && !visibleTickets.some((ticket) => ticket.id === selectedTicketId)) {
    selectedTicketId = visibleTickets[0]?.id || null;
  }

  setConnection(true);
  renderAll();
}

async function runTicketAction(action, body = null) {
  const ticket = selectedTicket();
  if (!ticket) {
    throw new Error("Select a ticket first.");
  }

  if (action === "assign" && !isAdmin()) {
    throw new Error("Only the admin account can assign tickets.");
  }

  if (action !== "assign" && !canManageTicket(ticket)) {
    throw new Error("This account cannot manage the selected ticket.");
  }

  await api(`tickets/${encodeURIComponent(ticket.id)}/${action}`, {
    method: "POST",
    ...(body ? { body: JSON.stringify(body) } : {})
  });
  await loadData();
}

async function requestUpdateForTicket(ticketId) {
  if (!isCustomer()) {
    return;
  }

  await api(`tickets/${encodeURIComponent(ticketId)}/request-update`, {
    method: "POST"
  });
  selectedTicketId = ticketId;
  await loadData();
  showToast("Update requested");
}

async function respondToUpdateForSelectedTicket(message) {
  const ticket = selectedTicket();
  if (!ticket || !isAgent() || !canManageTicket(ticket)) {
    throw new Error("Select one of your assigned tickets first.");
  }

  await api(`tickets/${encodeURIComponent(ticket.id)}/respond-update`, {
    method: "POST",
    body: JSON.stringify({ message })
  });
  agentUpdateResponse.value = "";
  await loadData();
  showToast("Update response sent");
}

function openTicketInDetails(ticketId) {
  selectedTicketId = ticketId;
  showView("tickets");
  renderAll();
}

function signIn(userKey) {
  currentUser = buildUserSession(userKey);
  selectedTicketId = null;
  persistSession();
  setLoginError("");
  applyAuthState();
  syncRoleUi(firstAllowedView());
  form.reset();
  applyTicketFormDefaults();
  loadData().catch((error) => setConnection(false, error.message));
}

function signOut() {
  if (modal.open) {
    modal.close();
  }

  currentUser = null;
  tickets = [];
  agents = [];
  dashboard = null;
  queues = {};
  slaMonitor = { over_sla: [], at_risk: [] };
  rules = [];
  selectedTicketId = null;
  activePriorityFilter = "all";
  apiOnline = false;
  clearSession();
  loginForm.reset();
  setLoginError("");
  applyAuthState();
}

loginForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const username = usernameInput.value.trim().toLowerCase();
  const password = passwordInput.value;
  const knownUsers = getKnownUsers();
  const matchedUser = Object.keys(knownUsers).find((userKey) => {
    const candidate = knownUsers[userKey];
    return candidate.username.toLowerCase() === username && candidate.password === password;
  });

  if (!matchedUser) {
    setLoginError("Invalid credentials. Use a demo account or a saved agent account.");
    return;
  }

  signIn(matchedUser);
});

logoutButton.addEventListener("click", signOut);

navItems.forEach((item) => {
  item.addEventListener("click", () => showView(item.dataset.viewTarget));
});

window.addEventListener("hashchange", () => {
  if (currentUser) {
    showView(window.location.hash.replace("#", ""));
  }
});

filterChips.forEach((chip) => {
  chip.addEventListener("click", () => {
    filterChips.forEach((item) => item.classList.remove("active"));
    chip.classList.add("active");
    activePriorityFilter = chip.dataset.priorityFilter;
    renderTable();
  });
});

searchInput.addEventListener("input", renderTable);
statusFilter.addEventListener("change", renderTable);

document.querySelector("#refreshData").addEventListener("click", () => {
  if (!currentUser) {
    return;
  }

  loadData().catch((error) => setConnection(false, error.message));
});

openTicketModalButton.addEventListener("click", () => {
  if (!canCreateTicket()) {
    return;
  }

  if (!apiOnline) {
    setConnection(false, "Backend is offline. Start XAMPP first.");
    return;
  }

  form.reset();
  applyTicketFormDefaults();
  modal.showModal();
});

customerNewTicketButton.addEventListener("click", () => {
  openTicketModalButton.click();
});

function handleCustomerUpdateCardClick(event) {
  const button = event.target.closest("[data-request-update-ticket]");
  if (!button || button.disabled) {
    return;
  }

  requestUpdateForTicket(button.dataset.requestUpdateTicket).catch((error) => setConnection(false, error.message));
}

document.querySelector("#customerDeadlineCards").addEventListener("click", handleCustomerUpdateCardClick);
document.querySelector("#customerTicketCards").addEventListener("click", handleCustomerUpdateCardClick);

document.querySelector("#agentUpdateCards").addEventListener("click", (event) => {
  const button = event.target.closest("[data-open-ticket]");
  if (!button) {
    return;
  }

  openTicketInDetails(button.dataset.openTicket);
});

document.querySelector("#closeTicketModal").addEventListener("click", () => modal.close());
document.querySelector("#cancelTicketModal").addEventListener("click", () => modal.close());

requestTicketUpdateButton.addEventListener("click", () => {
  const ticket = selectedTicket();
  if (!ticket) {
    return;
  }

  requestUpdateForTicket(ticket.id).catch((error) => setConnection(false, error.message));
});

agentResponseForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const message = agentUpdateResponse.value.trim();
  if (!message) {
    setConnection(false, "Write an update response before sending.");
    return;
  }

  respondToUpdateForSelectedTicket(message).catch((error) => setConnection(false, error.message));
});

agentAccountForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  if (!isAdmin()) {
    return;
  }

  const data = Object.fromEntries(new FormData(agentAccountForm).entries());
  const username = String(data.username || "").trim();
  const password = String(data.password || "");

  if (!username || !password) {
    setAgentFormError("Username and temporary password are required.");
    return;
  }

  if (isUsernameTaken(username)) {
    setAgentFormError("That username is already in use.");
    return;
  }

  setAgentFormError("");

  try {
    const payload = await api("agents", {
      method: "POST",
      body: JSON.stringify({
        name: String(data.name || "").trim(),
        email: String(data.email || "").trim(),
        role: String(data.role || "").trim(),
        skill_level: Number(data.skill_level || 1)
      })
    });

    storeAgentAccount(payload.agent, username, password);
    agentAccountForm.reset();
    await loadData();
    showToast(`Created agent account for ${payload.agent.name}`);
  } catch (error) {
    setAgentFormError(error.message);
  }
});

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  if (!canCreateTicket()) {
    return;
  }

  const data = new FormData(form);
  const body = Object.fromEntries(data.entries());

  if (isCustomer()) {
    body.requester_name = currentUser.name;
    body.requester_email = currentUser.email;
    delete body.agent_id;
  } else if (body.agent_id) {
    body.agent_id = Number(body.agent_id);
  } else {
    delete body.agent_id;
  }

  try {
    const payload = await api("tickets", {
      method: "POST",
      body: JSON.stringify(body)
    });
    selectedTicketId = payload.ticket.id;
    form.reset();
    applyTicketFormDefaults();
    modal.close();
    showView("tickets");
    await loadData();
    showToast(`Created ${payload.ticket.id}`);
  } catch (error) {
    setConnection(false, error.message);
  }
});

document.querySelector("#assignAgentBtn").addEventListener("click", async () => {
  if (!assignAgentSelect.value) {
    setConnection(false, "Choose an agent before saving the assignment.");
    return;
  }

  try {
    await runTicketAction("assign", { agent_id: Number(assignAgentSelect.value) });
    showToast("Assignment saved");
  } catch (error) {
    setConnection(false, error.message);
  }
});

document.querySelector("#escalateTicket").addEventListener("click", () => {
  runTicketAction("escalate")
    .then(() => showToast("Ticket escalated"))
    .catch((error) => setConnection(false, error.message));
});

document.querySelector("#reassignTicket").addEventListener("click", () => {
  runTicketAction("reassign")
    .then(() => showToast("Ticket reassigned"))
    .catch((error) => setConnection(false, error.message));
});

document.querySelector("#resolveTicket").addEventListener("click", () => {
  runTicketAction("resolve")
    .then(() => showToast("Ticket resolved"))
    .catch((error) => setConnection(false, error.message));
});

if (restoreSession()) {
  applyAuthState();
  syncRoleUi();
  applyTicketFormDefaults();
  loadData().catch((error) => setConnection(false, error.message));
} else {
  applyAuthState();
}
